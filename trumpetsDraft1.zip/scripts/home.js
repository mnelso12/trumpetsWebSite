jQuery(document).ready(function($){
	console.log(
	"Tiny bubbles In the wine Make me feel happy Ah, they make me feel fine Those tiny bubbles Make me warm all over With a feeling that I'm gonna Love you till the end of time So here's to the golden moon And here's to the silver sea And mostly here's a toast To you and me When the tiny bubbles (tiny bubbles) In the wine (in the wine) They make me feel happy (make me feel happy) Make me feel fine (make me feel fine) Those tiny bubbles (tiny bubbles) Make me warm all over (make me warm all over) With a feeling that I'm gonna (with a feeling that I'm gonna) Love you till the end of time Tiny bubbles (Oooh-a-licki) In the wine (ik-a-may-li) Make me feel happy(a-ka-oli) Ah, they make me feel fine(ik-a-ba-al-he) Those tiny bubbles Make me warm all over With a feeling that I'm gonna Love you till the end of time With a feeling that I'm gonna Love you till the end of time With a feeling that I'm gonna Love you till the end of time"); 
	$("#homePlayersButton").click(function(){
		console.log("players clicked");

	});
	
	$("#homeStatsButton").click(function(){
		console.log("stats clicked");
	});
	
	$("#homeFunButton").click(function(){
		console.log("fun clicked");
	});
	
	$("#homeSeeUsButton").click(function(){
		console.log("see us clicked");
	});
});


